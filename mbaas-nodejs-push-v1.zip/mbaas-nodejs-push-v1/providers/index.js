
module.exports = {
	apns: require('./apns.js'),
	gcm: require('./gcm.js'),
	mqtt: require('./mqtt.js')
};