//
//  MasterViewController.h
//  HaruStart
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController


@end

