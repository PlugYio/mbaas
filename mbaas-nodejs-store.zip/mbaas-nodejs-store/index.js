
module.exports = require('./lib/haru-nodejs-store');
