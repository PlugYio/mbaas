/**
 * Created by syntaxfish on 14. 11. 1..
 */

module.exports = {
    playGoogle: require('./playGoogle.js'),
    amazon: require('./amazon.js'),
    market360: require('./market360.js'),
    tstore: require('./tstore.js')
};