/**
 * Created by pheadra on 10/31/14.
 */
app.controller('SettingColloratorCtrl', ['$scope', function($scope) {




}]);
