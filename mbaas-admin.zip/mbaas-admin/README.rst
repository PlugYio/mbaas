Xitrum projects require Java 7+.

To create a new `Xitrum <http://xitrum-framework.github.io/>`_ project,
download project skeleton `xitrum-new.zip <https://github.com/xitrum-framework/xitrum-new/archive/master.zip>`_,
unzip, then run:

::

  sbt/sbt run

  sbt/sbt eclipse
  sbt/sbt gen-idea


  sb/sbt xitrum-package
  ./target/script/runner haru.Boot
::