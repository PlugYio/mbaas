/**
 * 고객센터 API의 호출 결과를 받는 Callback 함수들을 모아놓은 패키지.
 */
package com.haru.helpcenter.callback;