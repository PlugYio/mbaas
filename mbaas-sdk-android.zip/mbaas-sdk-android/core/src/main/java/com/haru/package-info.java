/**
 * Haru Android SDK.
 * <br/> 유저 관리, 데이터 관리, 파일 업로드, 오프라인 데이터 저장, 앱 설치정보 관리, 환경설정 API 등을 제공한다.
 */
package com.haru;