package com.haru.callback;

import com.haru.HaruException;

public interface DeleteCallback {
    public void done(HaruException exception);
}
