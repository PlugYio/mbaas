package com.haru.mime;

public enum HttpMultipartMode {
    STRICT,
    BROWSER_COMPATIBLE
}