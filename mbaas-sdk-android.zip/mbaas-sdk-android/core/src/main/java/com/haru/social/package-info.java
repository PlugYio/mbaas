/**
 * 소셜 로그인을 위한 패키지.
 * <br/> Facebook, Kakao 로그인을 편리하게 하기 위한 API를 제공한다.
 */
package com.haru.social;