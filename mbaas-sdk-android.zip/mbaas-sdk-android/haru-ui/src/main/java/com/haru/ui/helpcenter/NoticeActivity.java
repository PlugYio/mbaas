package com.haru.ui.helpcenter;

import android.app.Activity;

/**
 *
 */
public class NoticeActivity extends Activity {
}
