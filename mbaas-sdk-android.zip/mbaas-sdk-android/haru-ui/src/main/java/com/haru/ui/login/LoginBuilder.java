package com.haru.ui.login;

/**
 *
 */
public class LoginBuilder {

}
